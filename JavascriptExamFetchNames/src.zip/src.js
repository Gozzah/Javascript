var btn = document.getElementById("btnsend");
var person = document.getElementById("tblbody");
var gender = document.getElementById("gender");


var urlFemale = "http://uinames.com/api/?amount=25&region=denmark&gender=female";
var urlMale   = "http://uinames.com/api/?amount=25&region=denmark&gender=male";
var urlBoth =   "http://uinames.com/api/?amount=25&region=denmark";


btn.onclick = function(){
    getPersons();
};

var getPersons = function(){
    
   
person.innerHTML = "";
    var number = document.getElementById("amount").value;
if(gender.value =="female" ){
    fetch(urlFemale, 
    {method: "get"})
    .then(function(response){
        return response.text();
    }).then(function(text){
        console.log(text);
        var personObject = JSON.parse(text);
        for(var i = 0;i < number; i++){
           person.innerHTML += "<tr>" +"<td>" + personObject[i].name + "</td>" + "<td>" + personObject[i].surname + "</td>" +  "<td>" +personObject[i].gender + "</td>" + "</tr>";

 }
    })
}else if
    (gender.value =="male" ){
        fetch(urlMale, 
        {method: "get"})
        .then(function(response){
            return response.text();
        }).then(function(text){
            console.log(text);
            var personObject = JSON.parse(text);
            for(var i = 0;i < number; i++){
               person.innerHTML += "<tr>" +"<td>" + personObject[i].name + "</td>" + "<td>" + personObject[i].surname + "</td>" +  "<td>" +personObject[i].gender + "</td>" + "</tr>";
    
     }
        });
    }

    else if
    (gender.value =="both" ){
        fetch(urlBoth, 
        {method: "get"})
        .then(function(response){
            return response.text();
        }).then(function(text){
            console.log(text);
            var personObject = JSON.parse(text);
            for(var i = 0;i < number; i++){
               person.innerHTML += "<tr>" +"<td>" + personObject[i].name + "</td>" + "<td>" + personObject[i].surname + "</td>" +  "<td>" +personObject[i].gender + "</td>" + "</tr>";
    
     }
        });
    }


}
;